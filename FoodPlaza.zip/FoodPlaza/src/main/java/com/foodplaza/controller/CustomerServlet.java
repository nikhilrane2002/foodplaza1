package com.foodplaza.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.foodplaza.dao.CustomerDao_impl;
import com.foodplaza.pojo.Customer;

@WebServlet("/customer")
public class CustomerServlet extends HttpServlet{
	CustomerDao_impl cdi= new CustomerDao_impl();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session=req.getSession();
		PrintWriter out=resp.getWriter();
		String action=req.getParameter("action");
		if(action!=null && action.equals("delete"))
		{
			String cEmail=req.getParameter("emailId");
			boolean b=cdi.deleteCustomerById(cEmail);
			if(b) {
				resp.sendRedirect("Success.jsp");
			}
			else {
				resp.sendRedirect("Failed.jsp");
			}
		}
		else
		{
			List<Customer> clist=cdi.getAllCustomer();
			
			if(clist!=null && !(clist.isEmpty())) {
				session.setAttribute("cList", clist);
				resp.sendRedirect("CustomerList.jsp");
			}
			else
			{
				resp.sendRedirect("Failed.jsp");
			}
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String action=req.getParameter("action");
		if(action!=null && action.equals("AddCustomer"))
		{
			PrintWriter out=resp.getWriter();
			String cName=req.getParameter("name");
			String cEmail=req.getParameter("emailId");
			String cPass=req.getParameter("pass");
			String cAdd=req.getParameter("address");
			String cContact=req.getParameter("contactno");
			
			Customer cust=new Customer(cName, cEmail, cPass, cAdd, cContact);
			boolean b=cdi.addCustomer(cust);
			if(b) {
					resp.sendRedirect("Success.jsp");
				}
				else {
					resp.sendRedirect("Failed.jsp");
				}
		}
		else if(action!=null && action.equals("UpdateCustomer"))
		{
			String cEmail=req.getParameter("emailId");
			String cName=req.getParameter("name");
			String cPass=req.getParameter("pass");
			String cAdd=req.getParameter("address");
			String cContact=req.getParameter("contactno");
			
			Customer cust=new Customer(cName, cEmail, cPass, cAdd, cContact);
			cust.setcEmailId(cEmail);
			boolean b=cdi.updateCustomerById(cust);
			if(b) {
				resp.sendRedirect("Success.jsp");
				}
				else {
					resp.sendRedirect("Failed.jsp");
				}			
		}
	}
}
