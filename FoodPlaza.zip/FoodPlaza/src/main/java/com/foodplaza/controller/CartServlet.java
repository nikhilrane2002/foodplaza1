package com.foodplaza.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.foodplaza.dao.CartDao_Impl;
import com.foodplaza.pojo.Cart;
import com.foodplaza.pojo.Food;

@WebServlet("/cart")
public class CartServlet extends HttpServlet {
	CartDao_Impl cart=new CartDao_Impl();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session=req.getSession();
		PrintWriter out=resp.getWriter();
		String action=req.getParameter("action");
		if(action!=null && action.equals("delete")) {
			int cid=Integer.parseInt(req.getParameter("cartId"));
			boolean b=cart.deleteCart(cid);
			if(b) {
				resp.sendRedirect("cart");
			}
			else {
				resp.sendRedirect("Failed.jsp");
			}
		}
		else {
		 
		String email=(String)session.getAttribute("userEmail");	
		List<Cart> cartlist=cart.showCart(email);
		if(cartlist!=null && !(cartlist.isEmpty())){
			session.setAttribute("clist", cartlist);
			resp.sendRedirect("CartList.jsp");
		}
		else {
			resp.sendRedirect("Failed.jsp");
		}
		}
	
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
			String emailId=req.getParameter("email");
			int foodId=Integer.parseInt(req.getParameter("foodId"));
			String foodname=req.getParameter("foodname");
			Double foodprice=Double.parseDouble(req.getParameter("foodPrice"));
			Double foodTprice=Double.parseDouble(req.getParameter("tprice"));
			int foodqty=Integer.parseInt(req.getParameter("qty"));
			
			Cart crt=new Cart( foodId,emailId, foodname, foodprice, foodTprice, foodqty);
			boolean b=cart.addToCart(crt);
			if(b) {
				resp.sendRedirect("cart");
			}
			else {
				resp.sendRedirect("Failed.jsp");
			}
		
	}
}
