package com.foodplaza.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.foodplaza.dao.FoodDao_impl;
import com.foodplaza.pojo.Food;

@WebServlet("/food")
public class FoodServlet extends HttpServlet{
	FoodDao_impl fdi=new FoodDao_impl();
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session=req.getSession();
		PrintWriter out=resp.getWriter();
		String action=req.getParameter("action");
		if(action!=null && action.equals("delete")) {
			int foodid=Integer.parseInt(req.getParameter("foodId"));
			boolean b=fdi.deleteFoodById(foodid);
			if(b) {
				resp.sendRedirect("food");
			}
			else {
				resp.sendRedirect("Failed.jsp");
			}
		}
		else {
		
		List<Food> foodlist=fdi.getAllFood();
		if(foodlist!=null && !(foodlist.isEmpty())){
			session.setAttribute("flist", foodlist);
			resp.sendRedirect("FoodList.jsp");
		}
		else {
			resp.sendRedirect("Failed.jsp");
		}
		}
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String action=req.getParameter("action");
		if(action!=null && action.equals("AddFood"))
		{
			PrintWriter out=resp.getWriter();
			String FoodName=req.getParameter("foodname");
			String FoodType=req.getParameter("foodtype");
			String FoodCat=req.getParameter("foodcategory");
			double FoodPrice=Double.parseDouble(req.getParameter("foodprice"));
			
			Food food=new Food(FoodName, FoodType, FoodCat, FoodPrice);
			boolean b=fdi.addFood(food);
			if(b) {
				resp.sendRedirect("food");
			}
			else {
				resp.sendRedirect("Failed.jsp");
			}
		}			
		else if(action!=null && action.equals("UpdateFood"))
		{
			int foodId=Integer.parseInt(req.getParameter("foodid"));
			String FoodName=req.getParameter("foodname");
			String FoodType=req.getParameter("foodtype");
			String FoodCat=req.getParameter("foodcategory");
			double FoodPrice=Double.parseDouble(req.getParameter("foodprice"));
			
			Food food=new Food(FoodName, FoodType, FoodCat, FoodPrice);
			food.setFoodId(foodId);
			boolean b=fdi.updateFoodById(food);
			if(b) {
				resp.sendRedirect("food");
			}
			else {
				resp.sendRedirect("failed.jsp");
			}
		}
		
		
	}
}
