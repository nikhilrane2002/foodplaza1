package com.foodplaza.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.foodplaza.dao.AdminDao_Impl;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	AdminDao_Impl impl=new AdminDao_Impl();
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session=req.getSession();
		session.invalidate();
		resp.sendRedirect("index.jsp");
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session=req.getSession();
		String type=req.getParameter("type");
		String emailId=req.getParameter("username");
		String pass=req.getParameter("password");
		String action=req.getParameter("action");
		
		if(action!=null && action.equals("Login"))
		{
			if(type.equals("user")) {
			session.setAttribute("userEmail", emailId);
			
				boolean b=impl.userLogin(emailId, pass);
				if(b) {
					session.setAttribute("userEmail", emailId);
					resp.sendRedirect("index.jsp");
				}
				else {
					resp.sendRedirect("Failed.jsp");
				}
			}
			if(type.equals("admin"))
			{
				session.setAttribute("adminEmail", emailId);
				boolean b=impl.adminLogin(emailId, pass);
				if(b) {
					session.setAttribute("adminEmail", emailId);
					resp.sendRedirect("index.jsp");
				}
				else {
					resp.sendRedirect("Failed.jsp");
				}
			}
		}
		else if(action!=null && action.equals("ChangePassword"))
		{
			String newpass=req.getParameter("password");
			if(type.equals("user"))
			{
				boolean b=impl.userChangePassword(emailId, newpass);
				if(b) {
					resp.sendRedirect("Success.jsp");
				}
				else {
					resp.sendRedirect("Failed.jsp");
				}
			}
			if(type.equals("admin"))
			{
				boolean b=impl.adminChangePassword(emailId, newpass);
				if(b) {
					resp.sendRedirect("Success.jsp");
				}
				else {
					resp.sendRedirect("Failed.jsp");
				}
			}
		}
	}
}
