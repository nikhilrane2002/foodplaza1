package com.foodplaza.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.foodplaza.dao.CartDao_Impl;
import com.foodplaza.dao.OrderDao_Impl;
import com.foodplaza.pojo.Cart;
import com.foodplaza.pojo.Order;

@WebServlet("/placeOrder")
public class OrderController extends HttpServlet {
	OrderDao_Impl ordimpl=new OrderDao_Impl();
	CartDao_Impl crt= new CartDao_Impl();
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session= req.getSession();
		PrintWriter out=resp.getWriter();
		String email=(String)session.getAttribute("userEmail");
		//Order order=ordimpl.placeOrder(email);
		//out.println(order);
		Order placeOrder=ordimpl.placeOrder(email);
		if(placeOrder!=null) {
			boolean b=crt.clearCart(email);
			if(b) {
				req.setAttribute("order", placeOrder);
				RequestDispatcher rd=req.getRequestDispatcher("Biling.jsp");
				rd.forward(req, resp);
			}
		}
		else
		{
			resp.sendRedirect("Failed.jsp");
		}
		
		
	}
}
