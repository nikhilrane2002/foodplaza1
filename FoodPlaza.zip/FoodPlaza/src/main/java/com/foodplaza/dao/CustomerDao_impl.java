package com.foodplaza.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.foodplaza.pojo.Customer;
import com.foodplaza.utility.DBUtility;

public class CustomerDao_impl implements CustomerDao{
Connection con;
	PreparedStatement ps;
	ResultSet rs;
	String sql;
	int row;


	

	@Override
	public boolean addCustomer(Customer customer) {
		try {
		con=DBUtility.getConnect();
		sql="insert into Customer123_nikita (CustName,CustEmailId,CustPass,CustAddress,CustContactNo) values(?,?,?,?,?);";
		ps=con.prepareStatement(sql);
		ps.setString(1, customer.getCustomerName());
		ps.setString(2, customer.getcEmailId());
		ps.setString(3, customer.getcPassword());
		ps.setString(4, customer.getcAddress());
		ps.setString(5, customer.getcContactNo());
		row=ps.executeUpdate();
		if(row>0) {
			return true;
		}
		else {
			return false;
		}
		
		
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean updateCustomerById(Customer customer) {
		try {
		con=DBUtility.getConnect();
		sql="update  Customer123_nikita set  CustName=?,CustPass=?,CustAddress=?,CustContactNo=? where CustEmailId=?";
		ps=con.prepareStatement(sql);
		
		ps.setString(1, customer.getCustomerName());
		ps.setString(2, customer.getcPassword());
		ps.setString(3, customer.getcAddress());
		ps.setString(4, customer.getcContactNo());
		ps.setString(5, customer.getcEmailId());
		row=ps.executeUpdate();


		if(row>0) {
			return true;
		}
		else {
			return false;
		} 
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean deleteCustomerById(String cEmailId) {
		try {
			con=DBUtility.getConnect();
		sql="delete from Customer123_nikita where CustEmailId=?";
		ps=con.prepareStatement(sql);
		ps.setString( 1, cEmailId);
		row=ps.executeUpdate();
		if(row>0) {
			return true;
		}
		else {
			return false;
		}
	}catch(SQLException e) {
		e.printStackTrace();
	}
		
		return false;
	}

	@Override
	public List<Customer> getAllCustomer() {
		List<Customer>customerList=new ArrayList<>();
		try {
		con=DBUtility.getConnect();
		sql="select * from Customer123_nikita";
		ps=con.prepareStatement(sql);
		rs=ps.executeQuery();
		while(rs.next()) {
			Customer customer=new Customer();
			customer.setCustomerName(rs.getString("CustName"));
			customer.setcAddress(rs.getString("CustAddress"));
			customer.setcPassword(rs.getString("CustPass"));
			customer.setcContactNo(rs.getString("CustContactNo"));
			customer.setcEmailId(rs.getString("CustEmailId"));
			customerList .add(customer);
		}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return customerList;
	}

	@Override
	public Customer searchCustomerByEmailId(String cEmailId) {
		Customer customerList1=null;
		try {
		con=DBUtility.getConnect();
		sql="select * from Customer123_nikita where CustEmailId=?";
		ps=con.prepareStatement(sql);
		ps.setString(1, cEmailId);
		rs=ps.executeQuery();
		if(rs.next()) {
			customerList1=new Customer();
			customerList1.setCustomerName(rs.getString("CustName"));
			customerList1.setcAddress(rs.getString("CustAddress"));
			customerList1.setcPassword(rs.getString("CustPass"));
			customerList1.setcContactNo(rs.getString("CustContactNo"));
			customerList1.setcEmailId(rs.getString("CustEmailId"));
			
		}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return customerList1;
	}

}
